<?php

define("DB_SERVER", "localhost");
define("DB_USER", "webuser");
define("DB_PASS", "secretpassword");
define("DB_NAME", "globe_bank");
